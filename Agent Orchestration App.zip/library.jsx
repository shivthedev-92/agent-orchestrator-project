// library.jsx — sidebar agent library data + sidebar component

const AGENT_TEMPLATES = [
  // Data Pipeline
  { id: 'tpl-extractor',   name: 'Extractor',         role: 'Source ingestion',     group: 'Data Pipeline', tag: 'I/O',  defaultModel: 'sonnet-4', skills: ['SQL', 'HTTP', 'Pagination'], prompt: 'Extract records from the configured source. Honor pagination. Emit rows as JSONL.' },
  { id: 'tpl-transformer', name: 'Transformer',       role: 'Schema + cleaning',    group: 'Data Pipeline', tag: 'ETL',  defaultModel: 'sonnet-4', skills: ['Schema', 'Validation'], prompt: 'Normalize incoming rows. Coerce types. Drop nulls. Emit a strict schema.' },
  { id: 'tpl-loader',      name: 'Loader',            role: 'Sink writer',          group: 'Data Pipeline', tag: 'SINK', defaultModel: 'haiku-4', skills: ['Postgres','S3'], prompt: 'Write transformed rows to the destination. Use upsert keys.' },
  { id: 'tpl-validator',   name: 'Validator',         role: 'Quality checks',       group: 'Data Pipeline', tag: 'QA',   defaultModel: 'sonnet-4', skills: ['Assert','Stats'], prompt: 'Validate row counts and distributions. Halt on anomalies above threshold.' },

  // Travel
  { id: 'tpl-flight',      name: 'Flight Scout',      role: 'Searches flights',     group: 'Travel',        tag: 'API',  defaultModel: 'sonnet-4', skills: ['Search','Compare'], prompt: 'Find best flights matching constraints. Return top 5 with rationale.' },
  { id: 'tpl-hotel',       name: 'Hotel Curator',     role: 'Lodging recommender',  group: 'Travel',        tag: 'API',  defaultModel: 'sonnet-4', skills: ['Filter','Rank'], prompt: 'Find lodging within budget and walking distance to the itinerary anchors.' },
  { id: 'tpl-itinerary',   name: 'Itinerary Planner', role: 'Day-by-day builder',   group: 'Travel',        tag: 'PLAN', defaultModel: 'opus-4', skills: ['Reason','Schedule'], prompt: 'Build a day-by-day plan combining flight, hotel and activities. Respect timezones.' },
  { id: 'tpl-booker',      name: 'Booker',            role: 'Reservation agent',    group: 'Travel',        tag: 'TX',   defaultModel: 'sonnet-4', skills: ['Forms','Email'], prompt: 'Place reservations through the configured providers. Confirm by email.' },

  // Generic / Utility
  { id: 'tpl-router',      name: 'Router',            role: 'Conditional dispatch', group: 'Control Flow',  tag: 'CTRL', defaultModel: 'haiku-4', skills: ['Branch'], prompt: 'Inspect input and route to the appropriate downstream agent.' },
  { id: 'tpl-merger',      name: 'Merger',            role: 'Join multiple inputs', group: 'Control Flow',  tag: 'CTRL', defaultModel: 'haiku-4', skills: ['Merge'], prompt: 'Wait until all upstream inputs arrive, then forward as a single payload.' },
  { id: 'tpl-human',       name: 'Human Approval',    role: 'Pause for review',     group: 'Control Flow',  tag: 'HOLD', defaultModel: 'none',     skills: ['Approve'], prompt: 'Pause execution and request human confirmation before continuing.' },

  // Communication
  { id: 'tpl-notifier',    name: 'Notifier',          role: 'Sends status updates', group: 'Communication', tag: 'MSG',  defaultModel: 'haiku-4', skills: ['Email','Slack'], prompt: 'Send a brief status update to the configured channels with current results.' },
  { id: 'tpl-summarizer',  name: 'Summarizer',        role: 'Briefs the user',      group: 'Communication', tag: 'NLG',  defaultModel: 'sonnet-4', skills: ['Summary'], prompt: 'Produce a concise human-readable summary of the workflow output.' },

  // Research
  { id: 'tpl-research',    name: 'Researcher',        role: 'Web research agent',   group: 'Research',      tag: 'WEB',  defaultModel: 'sonnet-4', skills: ['Search','Cite'], prompt: 'Research the topic, gather sources and extract key findings.' },
  { id: 'tpl-critic',      name: 'Critic',            role: 'Reviews other agents', group: 'Research',      tag: 'EVAL', defaultModel: 'opus-4', skills: ['Critique'], prompt: 'Review the previous agent\'s output for accuracy and completeness.' },
];

const MODELS = [
  { id: 'opus-4',    name: 'Opus 4.5',     meta: 'reasoning · 200k' },
  { id: 'sonnet-4',  name: 'Sonnet 4.5',   meta: 'balanced · 200k' },
  { id: 'haiku-4',   name: 'Haiku 4.5',    meta: 'fast · 100k' },
  { id: 'gpt-class', name: 'Generalist L', meta: 'long ctx · 1M' },
  { id: 'mini-fast', name: 'Mini',         meta: 'tiny · 32k' },
  { id: 'none',      name: 'No model',     meta: 'pass-through' },
];

const SKILL_BANK = [
  'SQL','HTTP','Pagination','Schema','Validation','Postgres','S3','Assert','Stats',
  'Search','Compare','Filter','Rank','Reason','Schedule','Forms','Email','Slack',
  'Branch','Merge','Approve','Summary','Cite','Critique','Vector','Image','Code',
  'OCR','Transcribe','Translate','Crawl','Scrape','PDF',
];

function Library({ query, onQuery, tab, onTab, onStartDrag, onSpawnAt }) {
  const groups = React.useMemo(() => {
    const filtered = AGENT_TEMPLATES.filter(t => {
      if (tab !== 'all' && t.group !== tab) return false;
      if (!query) return true;
      const q = query.toLowerCase();
      return t.name.toLowerCase().includes(q)
          || t.role.toLowerCase().includes(q)
          || t.skills.some(s => s.toLowerCase().includes(q));
    });
    const map = {};
    for (const t of filtered) (map[t.group] ||= []).push(t);
    return map;
  }, [query, tab]);

  const TABS = ['all', 'Data Pipeline', 'Travel', 'Control Flow', 'Communication', 'Research'];

  return (
    <aside className="library">
      <div className="lib-search">
        <svg className="icon-search" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="7"/><path d="m20 20-3-3"/>
        </svg>
        <input placeholder="Search agents…" value={query} onChange={(e) => onQuery(e.target.value)} />
      </div>

      <div className="lib-tabs">
        {TABS.map(t => (
          <button key={t} className={`lib-tab ${tab === t ? 'active' : ''}`} onClick={() => onTab(t)}>
            {t === 'all' ? 'All' : t.split(' ')[0]}
          </button>
        ))}
      </div>

      <div className="lib-list">
        {Object.entries(groups).map(([grp, items]) => (
          <div key={grp}>
            <div className="lib-group-label">{grp}</div>
            {items.map(t => (
              <div key={t.id}
                   className="lib-card"
                   draggable
                   onDragStart={(e) => onStartDrag(e, t)}
                   onDoubleClick={() => onSpawnAt(t)}
                   title="Drag to canvas, or double-click to add">
                <div className="lib-av">
                  <RobotAvatar seed={t.id} size={32}/>
                </div>
                <div className="lib-meta">
                  <div className="lib-name">{t.name}</div>
                  <div className="lib-role">{t.role}</div>
                </div>
                <span className="lib-tag mono">{t.tag}</span>
              </div>
            ))}
          </div>
        ))}
        {Object.keys(groups).length === 0 && (
          <div style={{ color: 'var(--fg-faint)', fontSize: 12, padding: 24, textAlign: 'center' }}>
            No agents match “{query}”.
          </div>
        )}
      </div>

      <div className="lib-foot">
        <span>Drag onto canvas</span>
        <span className="kbd">⌘ + N</span>
      </div>
    </aside>
  );
}

window.AGENT_TEMPLATES = AGENT_TEMPLATES;
window.MODELS = MODELS;
window.SKILL_BANK = SKILL_BANK;
window.Library = Library;
