// panels.jsx — TopBar, Inspector, Run overlay

function TopBar({ theme, onTheme, running, onRun, onStop, agentCount, connCount, runStep, runOrder, runElapsed, dirty }) {
  return (
    <header className="topbar">
      <div className="brand">
        <div className="brand-mark"/>
        <div>
          <div className="brand-name">Orchestra</div>
        </div>
        <span className="brand-sub mono">v0.4</span>
      </div>

      <div className="crumbs">
        <span>Workspaces</span>
        <span className="sep">/</span>
        <span>Acme Travel</span>
        <span className="sep">/</span>
        <span className="cur">Trip planner v3{dirty ? <span style={{ color: 'var(--fg-faint)', marginLeft: 6 }}>•</span> : null}</span>
      </div>

      <div className="topbar-spacer"/>

      <div className={`runtime-pill ${running ? 'running' : ''}`}>
        <span className="dot"/>
        <span>{agentCount} agents</span>
        <span style={{ color: 'var(--fg-faint)' }}>·</span>
        <span>{connCount} edges</span>
        {running && <>
          <span style={{ color: 'var(--fg-faint)' }}>·</span>
          <span>step {Math.min(runStep + 1, runOrder.length)}/{runOrder.length}</span>
          <span style={{ color: 'var(--fg-faint)' }}>·</span>
          <span>{runElapsed}s</span>
        </>}
      </div>

      <div className="topbar-actions">
        <button className="tb-btn icon" title="Undo">
          <svg width="15" height="15" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none"><path d="M3 7v6h6"/><path d="M3 13a9 9 0 1 0 3-7l-3 3"/></svg>
        </button>
        <button className="tb-btn icon" title="Redo">
          <svg width="15" height="15" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none"><path d="M21 7v6h-6"/><path d="M21 13a9 9 0 1 1-3-7l3 3"/></svg>
        </button>
        <span style={{ width: 8 }}/>
        <button className="tb-btn">
          <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.07a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.06a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
          Settings
        </button>
        <button className="tb-btn">
          <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          Export
        </button>

        <span style={{ width: 8 }}/>
        <div className="theme-toggle" role="tablist" aria-label="Theme">
          <button className={theme === 'light' ? 'active' : ''} onClick={() => onTheme('light')} title="Light">
            <svg width="13" height="13" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
          </button>
          <button className={theme === 'dark' ? 'active' : ''} onClick={() => onTheme('dark')} title="Dark">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
          </button>
        </div>

        <span style={{ width: 6 }}/>
        {!running ? (
          <button className="run-btn" onClick={onRun}>
            <span className="play-tri"/> Run
          </button>
        ) : (
          <button className="run-btn running" onClick={onStop}>
            <span className="stop-sq"/> Stop
          </button>
        )}
      </div>
    </header>
  );
}

// ---------- Inspector ----------
function Inspector({ agent, onChange, onDelete, onChangeAvatarSeed, connectionsCount }) {
  if (!agent) {
    return (
      <aside className="inspector">
        <div className="insp-empty">
          <div>
            <div className="glyph">
              <svg width="22" height="22" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.6" fill="none">
                <rect x="3" y="4" width="18" height="14" rx="3"/>
                <line x1="3" y1="9" x2="21" y2="9"/>
                <line x1="8" y1="14" x2="16" y2="14"/>
              </svg>
            </div>
            <div className="t">Nothing selected</div>
            <div className="s">Click an agent or a connection on the canvas to edit.</div>
          </div>
        </div>
      </aside>
    );
  }

  const toggleSkill = (s) => {
    const next = agent.skills.includes(s)
      ? agent.skills.filter(x => x !== s)
      : [...agent.skills, s];
    onChange({ skills: next });
  };

  const seeds = [agent.id, agent.id + '-1', agent.id + '-2', agent.id + '-3', agent.id + '-4', agent.id + '-5'];

  return (
    <aside className="inspector">
      <div className="insp-head">
        <div className="av"><RobotAvatar seed={agent.avatarSeed} size={48}/></div>
        <div className="id">
          <div className="name">
            <input value={agent.name} onChange={(e) => onChange({ name: e.target.value })}/>
          </div>
          <div className="role">
            <input value={agent.role} onChange={(e) => onChange({ role: e.target.value })}/>
          </div>
        </div>
        <button className="tb-btn icon" title="Delete agent" onClick={onDelete}>
          <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>
        </button>
      </div>

      <div className="insp-body">
        {/* Avatar */}
        <div className="fld">
          <div className="fld-label"><span>Avatar</span><span className="hint">click to reroll</span></div>
          <div className="av-pick">
            {seeds.map(seed => (
              <button key={seed}
                      className={`av-tile ${agent.avatarSeed === seed ? 'active' : ''}`}
                      onClick={() => onChangeAvatarSeed(seed)}>
                <RobotAvatar seed={seed} size={40}/>
              </button>
            ))}
          </div>
        </div>

        {/* Model */}
        <div className="fld">
          <div className="fld-label"><span>Model</span></div>
          <div className="model-grid">
            {MODELS.slice(0, 6).map(m => (
              <button key={m.id}
                      className={`model-tile ${agent.model === m.id ? 'active' : ''}`}
                      onClick={() => onChange({ model: m.id })}>
                <div className="mt-name">{m.name}</div>
                <div className="mt-meta">{m.meta}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Prompt */}
        <div className="fld">
          <div className="fld-label">
            <span>System prompt</span>
            <span className="hint">{agent.prompt.length} chars</span>
          </div>
          <textarea
            value={agent.prompt}
            placeholder="Describe what this agent should do…"
            onChange={(e) => onChange({ prompt: e.target.value })}
          />
        </div>

        {/* Skills */}
        <div className="fld">
          <div className="fld-label"><span>Skills</span><span className="hint">{agent.skills.length} active</span></div>
          <div className="skill-row">
            {SKILL_BANK.slice(0, 22).map(s => (
              <button key={s}
                      className={`skill-pill ${agent.skills.includes(s) ? 'on' : ''}`}
                      onClick={() => toggleSkill(s)}>
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Attributes */}
        <div className="fld">
          <div className="fld-label"><span>Attributes</span></div>
          <div className="attr-row">
            <span className="attr-label">Temperature</span>
            <span className="attr-val">{agent.temperature.toFixed(2)}</span>
          </div>
          <input className="range" type="range" min="0" max="1" step="0.05"
                 value={agent.temperature}
                 onChange={(e) => onChange({ temperature: parseFloat(e.target.value) })}/>
          <div className="attr-row" style={{ marginTop: 6 }}>
            <span className="attr-label">Max tokens</span>
            <span className="attr-val">{agent.maxTokens}</span>
          </div>
          <input className="range" type="range" min="256" max="8192" step="128"
                 value={agent.maxTokens}
                 onChange={(e) => onChange({ maxTokens: parseInt(e.target.value) })}/>
          <div className="attr-row" style={{ marginTop: 6 }}>
            <span className="attr-label">Retries</span>
            <span className="attr-val">{agent.retries}</span>
          </div>
          <input className="range" type="range" min="0" max="5" step="1"
                 value={agent.retries}
                 onChange={(e) => onChange({ retries: parseInt(e.target.value) })}/>
        </div>

        {/* I/O */}
        <div className="fld">
          <div className="fld-label"><span>I/O schema</span></div>
          <select value={agent.outputSchema} onChange={(e) => onChange({ outputSchema: e.target.value })}>
            <option value="freeform">Freeform text</option>
            <option value="json">Strict JSON</option>
            <option value="rows">Tabular rows</option>
            <option value="binary">Binary blob</option>
          </select>
        </div>

        {/* Connections */}
        <div className="fld">
          <div className="fld-label"><span>Connections</span><span className="hint">{connectionsCount} edges</span></div>
          <div style={{ fontSize: 11.5, color: 'var(--fg-dim)', lineHeight: 1.5 }}>
            Drag from the right port of this card to another agent's left port to relay messages.
          </div>
        </div>
      </div>
    </aside>
  );
}

// ---------- Run overlay ----------
function RunOverlay({ running, agents, runOrder, runStep, runElapsed, log }) {
  if (!running && log.length === 0) return null;
  const stages = runOrder.length || 1;
  return (
    <div className="run-overlay">
      <div className="run-card">
        <div className="run-title">
          <b>{running ? 'Running orchestration' : 'Last run'}</b>
          <span className="timer">{runElapsed.toFixed(1)}s</span>
        </div>
        <div className="run-stages">
          {Array.from({ length: stages }).map((_, i) => (
            <div key={i} className={`run-stage ${i < runStep ? 'done' : i === runStep && running ? 'active' : ''}`}/>
          ))}
        </div>
      </div>

      {log.length > 0 && (
        <div className="run-log">
          {log.slice(-8).map((l, i) => (
            <div key={i}>
              <span className="ts">{l.t}</span>
              <span className="who">{l.who}</span>
              <span> </span>
              <span className={l.kind === 'ok' ? 'ok' : l.kind === 'err' ? 'err' : ''}>{l.msg}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

window.TopBar = TopBar;
window.Inspector = Inspector;
window.RunOverlay = RunOverlay;
